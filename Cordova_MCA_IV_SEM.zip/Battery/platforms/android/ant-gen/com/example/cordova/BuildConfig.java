/** Automatically generated file. DO NOT MODIFY */
package com.example.cordova;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}